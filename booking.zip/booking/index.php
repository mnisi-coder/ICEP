<?php
session_start();


require_once('dbconnection.php');
include("nav.php")
?>
    </div>
    <div id="hero">
        <div id="hero-content">
            <div id="content">
			
			<?php
			if(empty($_SESSION['name']))
			{	
				echo("<H2>VISITOR</H2>");
									
                echo '<h1>Welcome To Health Care Service Centre</h1>';
                echo '<p>Make online bookings for your Covid testing and Screening</p>';
			}else
			{
				echo"<h1>";
				echo $_SESSION['name']." ".$_SESSION['surname'];
				echo"</h1>";				
                echo '<h1>Welcome To Health Care Service Centre</h1>';
                echo '<p>Make online bookings for your Covid testing and Screening</p>';
			}
			?>
            </div>
        </div>
    </div>
    <div id="news">
        <div class="container">
            <div id="latest-news">
              
                
            <div class="left-image-post"><!--this is the first box of things -->
            <div class="row">
              <div class="col-md-6">
                <div class="left-image">
                  <img src="assets/images/info.png" alt="" />
                </div>
              </div>
              <div class="col-md-6">
                <div class="right-text">
                  <h4>COVID-19 INFORMATION</h4>
                  <p>
                    Donec tristique feugiat lacus, at sollicitudin nunc euismod
                    sed. Mauris viverra, erat non sagittis gravida, elit dui
                    mollis ante, sit amet eleifend purus ligula eget eros. Sed
                    tincidunt quam vitae neque pharetra dignissim eget ut
                    libero.
                  </p>
                  <div class="white-button">
                    <a href="#">Read More</a>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- Endn of the first box-->
				
				
				
		<div class="right-image-post"> <!--Second box starts here-->
            <div class="row">
              <div class="col-md-6">
                <div class="left-text">
                  <h4>COVID TESTING</h4>
                  <p>
                    </p>Two kinds of tests are available for COVID-19: viral tests and antibody tests.</p>
					<ul>
					<li>A viral test tells you if you have a current infection.</li>
					<li>An antibody test might tell you if you had a past infection.</li>
						</ul>
                  </p>
                  <div class="white-button">
                    <a href="https://www.cdc.gov/coronavirus/2019-ncov/symptoms-testing/testing.html">Read More</a>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="right-image">
                  <img src="assets/images/testing.jpg" alt="" />
                </div>
              </div>
            </div>
          </div><!--end of second box-->
					
					
					
			            <div class="left-image-post"><!--this is the THIRD box of things -->
            <div class="row">
              <div class="col-md-6">
                <div class="left-image">
                  <img src="assets/images/screen.png" alt="" />
                </div>
              </div>
              <div class="col-md-6">
                <div class="right-text">
                  <h4>SCREENING INNFORMATION</h4>
                  <p>
                    <p>User will be asked questions in form to find out if they show the COVID 19(corona virus) Symptoms. A person will therefore, be screened to establish the following:</p>
<ul>
  <li>if a person has travelled to a high risk country in the last 14 days</li>
  <li>if a person shows symptoms such as fever, cough and difficulty in breathing</li>
  <li>if a  person shows symptoms such as fever, cough and difficulty in breathing</li></ul>
                  </p>
                  <div class="white-button">
                    <a href="http://www.health.gov.za/index.php/gf-tb-program/477-covid-19-screening">Read More</a>
                  </div>
                </div>
              </div>
            </div>
          </div><!-- Endn of the first box-->		
					
               
                <hr>
                <div id="quick-updates">
                    <h3>Quick Updates</h3>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th id="date">Date</th>
                                    <th>Event</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <div><span id="time">08:23</span><span id="day">Mon</span><span id="date">10 Sep 2020</span></div>
                                    </td>
                                    <td>First years students to submit their details to mentors lab</td>
                                </tr>
                                <tr>
                                    <td>
                                        <div><span id="time">08:23</span><span id="day">Mon</span><span id="date">10 Sep 2020</span></div>
                                    </td>
                                    <td>Open labs are now operational</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <hr>
                </div>
            </div>
        </div>
    </div>
<!-- Footer -->
<footer class="page-footer font-small mdb-color lighten-3 pt-4">

  <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mr-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Content -->
        <h5 class="font-weight-bold text-uppercase mb-4">HEALTH CARE SERVICE CENTRE</h5>
        <p>A Testing centre for covid ill patints</p>
        <p>more information to come here</p>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Links -->
        <h5 class="font-weight-bold text-uppercase mb-4">About</h5>

        <ul class="list-unstyled">
          <li>
            <p>
              <a href="#!">TEAM</a>
            </p>
          </li>
          <li>
            <p>
              <a href="#!">ABOUT US</a>
            </p>
          </li>

        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="font-weight-bold text-uppercase mb-4">Address</h5>

			<div id="googleMap" style="width:100%;height:400px;"></div>
		  <!--<div id="map"></div>-->

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 text-center mx-auto my-4">

        <!-- Social buttons -->
        <h5 class="font-weight-bold text-uppercase mb-4">Follow Us</h5>

        <!-- Facebook -->
        <a type="button" class="btn-floating btn-fb">
          <i class="fab fa-facebook-f"></i>
        </a>
        <!-- Twitter -->
        <a type="button" class="btn-floating btn-tw">
          <i class="fab fa-twitter"></i>
        </a>
        <!-- Google +-->
        <a type="button" class="btn-floating btn-gplus">
          <i class="fab fa-google-plus-g"></i>
        </a>
        <!-- Dribbble -->
        <a type="button" class="btn-floating btn-dribbble">
          <i class="fab fa-dribbble"></i>
        </a>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="https://jalimnsi.cite/">Jali Mnisi</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/script.js"></script>
	
	
	
	
	
	
	
	
	<!--for maps-->
	<script>
function myMap() {
var mapProp= {
  center:new google.maps.LatLng(-26.2041, 28.0473),
  zoom:5,
};
var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
	
	
	
        // The marker, positioned at Uluru
        const marker = new google.maps.Marker({
          position: (-26.2041, 28.0473),
          map: mapProp,
        });	
}
</script>

<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY&callback=myMap"></script>
</body>

</html>
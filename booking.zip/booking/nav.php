<!DOCTYPE html>
<html style="font-family: 'Open Sans', sans-serif;">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Student Online Support</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" href="assets/css/styles.css">
	
	
	
	<!--for maps-->
	<script
      src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap&libraries=&v=weekly"
      defer
    ></script>
    <style type="text/css">
      /* Set the size of the div element that contains the map */
      #map {
        height: 300px;
        /* The height is 400 pixels */
        width: 100%;
        /* The width is the width of the web page */
      }
    </style>
    <script>
      // Initialize and add the map
      function initMap() {
        // The location of Uluru
        const johannesburg = { lat: -25.344, lng: 131.036 };
        // The map, centered at Uluru
        const map = new google.maps.Map(document.getElementById("map"), {
          zoom: 4,
          center: Johannessburg,
        });
        // The marker, positioned at Uluru
        const marker = new google.maps.Marker({
          position: Joohannesburg,
          map: map,
        });
      }
    </script>
</head>

<body>
    <div id="top-nav">
        <nav class="navbar navbar-light navbar-expand-md fixed-top fixed-top">
            <div class="container-fluid">
                <div id="logo"><img class="img-fluid" id="logo-img" src="assets/img/logo.png"></div><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav text-right ml-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link active" href="index.php">HOME</a></li>
                        
                        
						<?php
						if(empty($_SESSION['name']))
						{
							echo '<li class="nav-item" role="presentation"><a class="nav-link active" href="http://jalimnisi.site/">ABOUT</a></li>';
                        echo '<li class="nav-item" role="presentation"><a class="nav-link active" href="signin.php">SIGN IN</a></li>';
						
						}else{
							echo'<li class="nav-item dropdown"><a class="dropdown-toggle nav-link" data-toggle="dropdown" aria-expanded="false" href="#">MAKE RESEVATIONS</a>
                            <div class="dropdown-menu" role="menu">
								
								<a class="dropdown-item" role="presentation" href="test.php">Covid Testing</a>
								<a class="dropdown-item" role="presentation" href="screen.php">Covid Screening</a>
							</div>
                        </li> ';
							echo'<li class="nav-item" role="presentation"><a class="nav-link active" href="http://jalimnisi.site/">ABOUT</a></li>';
							echo '<li class="nav-item" role="presentation"><a class="nav-link active" href="logout.php">LOGOUT</a></li>';
							
						
						}
						?>
                    </ul>
            </div>
    </div>
    </nav>
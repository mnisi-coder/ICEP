-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2020 at 12:38 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: booking
--

-- --------------------------------------------------------

--
-- Table structure for table booking
--

CREATE TABLE booking (
  id varchar(13) NOT NULL,
  name varchar(255) NOT NULL,
  surname varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  address varchar(255) NOT NULL,
  cellno varchar(255) NOT NULL,
  gender varchar(255) NOT NULL,
  bookingDate date NOT NULL,
  time varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table booking
--

INSERT INTO booking (id, name, surname, email, address, cellno, gender, bookingDate, time) VALUES
('9707086297083', 'jali', 'mnisi', 'mnisi@gmail.com', 'hasahgsagjgJGJAGSJAGJSGJGSJH', '', 'male', '2020-12-04', '09'),
('9707086297083', 'jali', 'mnisi', 'mnisi@gmail.com', 'hasahgsagjgJGJAGSJAGJSGJGSJH', '', 'male', '2020-12-04', '09'),
('9707086297083', 'jali', 'mnisi', 'mnisi@gmail.com', 'hasahgsagjgJGJAGSJAGJSGJGSJH', '', 'male', '2020-12-04', '09'),
('9707086297083', 'jali', 'mnisi', 'mnisi@gmail.com', 'hasahgsagjgJGJAGSJAGJSGJGSJH', '', 'male', '2020-12-04', '09'),
('9707086297083', 'jali', 'mnisi', 'mnisi@gmail.com', 'hasahgsagjgJGJAGSJAGJSGJGSJH', '', 'male', '2020-12-04', '09'),
('9707086297083', 'jali', 'mnisi', 'mnisi@gmail.com', 'hasahgsagjgJGJAGSJAGJSGJGSJH', '', 'male', '2020-12-04', '08'),
('9707086297083', 'jali', 'mnisi', 'mnisi@gmail.com', 'hasahgsagjgJGJAGSJAGJSGJGSJH', '', 'male', '2020-12-10', '10');

-- --------------------------------------------------------

--
-- Table structure for table patient
--

CREATE TABLE patient (
  id varchar(13) NOT NULL,
  name varchar(255) NOT NULL,
  surname varchar(255) NOT NULL,
  gender varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  address varchar(255) NOT NULL,
  password varchar(255) NOT NULL,
  cellno varchar(255) NOT NULL,
  posting_date date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table patient
--

INSERT INTO patient (id, name, surname, gender, email, address, password, cellno, posting_date) VALUES
('9707086297083', 'jali', 'mnisi', 'male', 'mfanafuthimdawe@gmail.com', 'hasahgsagjgJGJAGSJAGJSGJGSJH', '4192362abe5b833aa06f536de8300273', '0653572171', '2020-12-04');

-- --------------------------------------------------------

--
-- Table structure for table screening
--

CREATE TABLE screening (
  screenID int(11) NOT NULL,
  id varchar(255) NOT NULL,
  bookingDate date NOT NULL,
  q1 varchar(255) NOT NULL,
  q2 varchar(255) NOT NULL,
  q3 varchar(255) NOT NULL,
  q4 varchar(255) NOT NULL,
  q5 varchar(255) NOT NULL,
  q6 varchar(255) NOT NULL,
  q7 varchar(255) NOT NULL,
  q8 varchar(255) NOT NULL,
  comment varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table patient
--
ALTER TABLE patient
  ADD PRIMARY KEY (id);

--
-- Indexes for table screening
--
ALTER TABLE screening
  ADD PRIMARY KEY (screenID);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table screening
--
ALTER TABLE screening
  MODIFY screenID int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
